package com.example.airlines;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    MyAdapter adapter;
    List<Example> exampleList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recycle);
        adapter = new MyAdapter(exampleList, MainActivity.this);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this, RecyclerView.VERTICAL, false));
        recyclerView.setAdapter(adapter);
        getdata();
    }

    public void getdata() {

        Retrofit retrofit = RetrofitClient.getRetrofit();
        ApiService apiService = retrofit.create(ApiService.class);

        Call<List<Example>> call = apiService.getdetails();
        call.enqueue(new Callback<List<Example>>() {
            @Override
            public void onResponse(Call<List<Example>> call, Response<List<Example>> response) {
               exampleList = response.body();
               // exampleList = new ArrayList<>(Arrays.asList(jsonresponse.getExamples()));
                adapter = new MyAdapter(exampleList, MainActivity.this);
                //LinearLayoutManager manager=new LinearLayoutManager(MainActivity.this,RecyclerView.VERTICAL,false);
                recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this, RecyclerView.HORIZONTAL, false));
                recyclerView.setAdapter(adapter);

            }

            @Override
            public void onFailure(Call<List<Example>> call, Throwable t) {
                Log.d("Error", t.getMessage());
            }
        });
    }
}