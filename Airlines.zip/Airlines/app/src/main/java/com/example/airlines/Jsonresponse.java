package com.example.airlines;

public class Jsonresponse {
    private Example[] examples;

    public Example[] getExamples() {
        return examples;
    }

    public void setExamples(Example[] examples) {
        this.examples = examples;
    }
}
