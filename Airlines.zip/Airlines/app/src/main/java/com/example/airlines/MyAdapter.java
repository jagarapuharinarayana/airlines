package com.example.airlines;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    List<Example> example;
    Context context;

    public MyAdapter(List<Example> example, Context context) {
        this.example = example;
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.first_api, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Example data = example.get(position);
        holder.country_.setText(data.getName());
        holder.counrty_name.setText(data.getCountry());
        holder.counrty_slogan.setText(data.getSlogan());
        holder.counrty_head_quarter.setText(data.getHeadQuaters());
        holder.counrty_website.setText(data.getWebsite());
        holder.counrty_established.setText(data.getEstablished());
        Glide.with(context).load(data.getLogo()).into(holder.logo_image);


    }

    @Override
    public int getItemCount() {
        return example.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView country_, counrty_name, counrty_slogan, counrty_head_quarter, counrty_website, counrty_established;
        ImageView logo_image;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            country_ = itemView.findViewById(R.id.country_);
            counrty_name = itemView.findViewById(R.id.counrty_name);
            counrty_slogan = itemView.findViewById(R.id.counrty_slogan);
            counrty_head_quarter = itemView.findViewById(R.id.counrty_head_quarter);
            counrty_website = itemView.findViewById(R.id.counrty_website);
            counrty_established = itemView.findViewById(R.id.counrty_established);
            logo_image = itemView.findViewById(R.id.logo_image);
        }
    }
}
